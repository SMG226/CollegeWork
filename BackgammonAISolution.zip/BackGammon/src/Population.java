import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.stream.IntStream;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Population extends Thread {
	private int popSize;//size of population
	private int gens;// the number of generations
	private int generations = 0;// current generation
	private int geneSize;// size of gene
	private ArrayList<Individual> population = new ArrayList<Individual>();
	private ArrayList<Individual> tournamentPopulation = new ArrayList<Individual>();
	private JFrame frame = new JFrame("Backgammon");
	private int[] score;
	private boolean finished;
	private double mutationRate;
	private int selection;

	public Population( int generations,int size, int gSize, double mRate, int select) {
		this.popSize = size;
		this.gens = generations;
		this.geneSize = gSize;
		this.mutationRate = mRate;
		this.score = new int[popSize];
		this.selection = select;
		frame.setVisible(true);
		frame.setSize(800, 450);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	public void initPopulation() {
		for (int i = 0; i < popSize; i++) {
			Individual genome = new Individual(geneSize);
			population.add(genome);
		}		
	}
	public void run() {
		int count1= 0;
		int count2= 0;
		int[] scores = new int[2];
		double[] gene = {1,1,1,1,1,1,1,1,1,1};
		int valls[] = new int[100];
		int valls2[] = new int[100];
		switch(selection){
		case 0:// Trains Roulette wheel selection
			WriteToCSV("/BackgammonProject/Results/Initial.csv", "Initial Population");
			while (!finished) {				
				runGame();
				rouletteWheel();
				System.out.println(generations);
				generations++;
				if (generations >= gens) {
					finished = true;
					WriteToCSV("/BackgammonProject/Results/Roulette.csv", "End Population");
				}
			}
			break;
		case 1://Trains Tournament selection
			WriteToCSV("/BackgammonProject/Results/Initial.csv", "Initial Population");
			while (!finished) {
				tournamentSelection();
				System.out.println(generations);
				generations++;
				if (generations >= gens) {
					finished = true;
					WriteToCSV("/BackgammonProject/Results/Tournament.csv", "End Population");
				}
			}
			break;
		case 2://test read file only used for debugging
			int j = 2;
			population = ReadFromCSV("/BackgammonProject/Results/Tournament.csv");
			population.remove(population.size()-1);
			for(Individual i: population){
				System.out.println(j + " " + Arrays.toString(i.getGenome()));
				j++;
			}
			break;
		case 3://Initial vs Tournament... used for testing 
			population = ReadFromCSV("/BackgammonProject/Results/Initial.csv");
			population.remove(population.size()-1);
			tournamentPopulation = ReadFromCSV("/BackgammonProject/Results/Tournament.csv");
			tournamentPopulation.remove(population.size()-1);
			for (int i = 0; i < population.size()-1; i++) {
				JPanel gb = new GameBoard(population.get(i).getGenome(), tournamentPopulation.get(i).getGenome(),true,true);
				frame.add(gb);
				scores = ((GameBoard) gb).calcFinished();
				count1 = count1+ scores[0];
				count2 = count2+ scores[1];
				System.out.println(i + " : " + count1 + " " + count2);
			}
			break;
		case 4://Initial vs Roulette... used for testing
			population = ReadFromCSV("/BackgammonProject/Results/Initial.csv");
			population.remove(population.size()-1);
			tournamentPopulation = ReadFromCSV("/BackgammonProject/Results/Roulette.csv");
			tournamentPopulation.remove(population.size()-1);
			for (int i = 0; i < population.size()-1; i++) {
				JPanel gb = new GameBoard(population.get(i).getGenome(), tournamentPopulation.get(i).getGenome(),true,true);
				frame.add(gb);
				scores = ((GameBoard) gb).calcFinished();
				count1 = count1+ scores[0];
				count2 = count2+ scores[1];
				System.out.println(i + " : " + count1 + " " + count2);
			}
			break;
		case 5://Greedy vs Tournament/ selection... Change file location as needed		
			tournamentPopulation = ReadFromCSV("/BackgammonProject/Results/Tournament.csv");
			tournamentPopulation.remove(population.size()-1);
			for(int c =0; c < 100; c++){
				for (int i = 0; i < population.size()-1; i++) {
					JPanel gb = new GameBoard(gene, tournamentPopulation.get(i).getGenome(),true,true);
					frame.add(gb);
					scores = ((GameBoard) gb).calcFinished();
					if(scores[0] > scores[1]){//if player1 loses
						count2++;
					}else{//player 2 loses
						count1++;
					}
					System.out.println(i + " : " + count1 + " " + count2);
				}
				valls[c] = count1;
				valls2[c] = count2;
				count1 = 0;
				count2 = 0;
			}
			WriteResults("/BackgammonProject/Results/GR.csv","Greedy vs Tournament " +Integer.toString(generations) + "_100_"+ Double.toString(mutationRate) , valls, valls2);
			break;	
		case 6://Play two populations against each other
			population = ReadFromCSV("/BackgammonProject/Results/Initial.csv");
			population.remove(population.size()-1);
			tournamentPopulation = ReadFromCSV("/BackgammonProject/Results/Tournament.csv");
			tournamentPopulation.remove(population.size()-1);
			for(int c =0; c < 100; c++){
				for (int i = 0; i < population.size()-1; i++) {
					JPanel gb = new GameBoard(population.get(i).getGenome(), tournamentPopulation.get(i).getGenome(),true,true);
					frame.add(gb);
					scores = ((GameBoard) gb).calcFinished();
					if(scores[0] > scores[1]){//if player1 loses
						count2++;
					}else{//player 2 loses
						count1++;
					}
					System.out.println(i + " : " + count1 + " " + count2);
				}
				valls[c] = count1;
				valls2[c] = count2;
				count1 = 0;
				count2 = 0;
			}
			WriteResults("/BackgammonProject/Results/Results1.csv","Initial vs Tournament " +Integer.toString(generations) + "_100_"+Double.toString(mutationRate) , valls, valls2);
			break;
		case 7: // two player backgammon
			JPanel panel = new JPanel();
			panel = new GameBoard(gene, gene, false, false);
			frame = new JFrame("Backgammon");
			frame.setVisible(true);
			frame.setSize(800, 450);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);			
			frame.add(panel);
			break;
		case 8: // greedy algorithm one turn at a time.
			JPanel p = new JPanel();
			p = new GameBoard(gene, gene, false, true);
			frame = new JFrame("Backgammon");
			frame.setVisible(true);
			frame.setSize(800, 450);
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);			
			frame.add(p);
			break;
		}
		
	}

	public void runGame() {
		int[] scores = new int[2];
		for (int i = 0; i < population.size() - 1; i = i + 2) {
			JPanel gb = new GameBoard(population.get(i).getGenome(), population.get(i + 1).getGenome(),true,true);
			frame.add(gb);
			scores = ((GameBoard) gb).calcFinished();
			score[i] = scores[0];
			score[i + 1] = scores[1];
			System.out.println(i + " : " + (i + 1) + Arrays.toString(scores));
		}
		int sum = IntStream.of(score).sum();
		for (int i = 0; i < score.length; i++) {
			score[i] = 375 - score[i];
			population.get(i).setFitness(score[i]);
		}
		System.out.println(Arrays.toString(score));
		System.out.println(">>>>>" + sum);
	}

	public void rouletteWheel() {
		ArrayList<Individual> genePool = new ArrayList<Individual>();
		int numSlots;
		for (int i = 0; i < popSize; i++) { // Add to breeding pool
			if(population.get(i).getFitness() == 375){
				numSlots = 200;
			}else{
				numSlots = (int) (((population.get(i).getFitness())/375)*100);
			}
			for (int j = 0; j < numSlots; j++) {
				genePool.add(population.get(i)); // Add this member of the
													// population numSlots
													// times to the mating
													// pool
			}
		}

		if (genePool.size() == 0) {
			System.out.println("Zero size mating pool in generation " + generations);
			for (int i = 0; i < popSize; i++) {
				int random_individual = (int) (Math.random() * popSize - 1);
				genePool.add(population.get(random_individual));
			}
		}

		for (int i = 0; i < popSize; i++) {
			int a = (int) (Math.random() * genePool.size());
			int b = (int) (Math.random() * genePool.size());
			Individual partnerA = genePool.get(a);
			Individual partnerB = genePool.get(b);
			Individual child = partnerA.Crossover(partnerB);
			child.mutate(mutationRate);
			population.set(i, child);
		}
	} 
	public void tournamentSelection() {
		/**
		 * Shuffles the population and plays pairs off against each other. The
		 * winner will be added to the next generation.
		 * 
		 */
		int[] scores = new int[2];
		Collections.shuffle(population);
		ArrayList<Individual> genePool = new ArrayList<Individual>();
		//Tournament
		for (int i = 0; i < population.size() - 1; i = i + 2) {
			JPanel gb = new GameBoard(population.get(i).getGenome(), population.get(i + 1).getGenome(),true,true);
			frame.add(gb);
			Individual player1 = population.get(i);
			Individual player2 = population.get(i+1);
			scores = ((GameBoard) gb).calcFinished();
			score[i] = scores[0];
			score[i + 1] = scores[1];
			if(scores[0] > scores[1]){
				genePool.add(player2);
			}else{
				genePool.add(player1);
			}
		}
		//Next generation
		if (genePool.size() == 0) {//If no gene pool
			System.out.println("Zero size gene pool in generation " + generations);
			for (int i = 0; i < popSize; i++) {
				int random_individual = (int) (Math.random() * popSize - 1);
				genePool.add(population.get(random_individual));
			}
		}
		//Apply crossover and mutation
		for (int i = 0; i < popSize; i++) {
			int a = (int) (Math.random() * genePool.size());
			int b = (int) (Math.random() * genePool.size());
			Individual partnerA = genePool.get(a);
			Individual partnerB = genePool.get(b);
			Individual child = partnerA.Crossover(partnerB);
			child.mutate(mutationRate);
			population.set(i, child);
		}	
	}
	public void WriteResults(String location, String name, int[] player1, int[]player2){
		FileWriter csvWrite = null;
		try {
			csvWrite = new FileWriter(location);
			csvWrite.append(name);
			csvWrite.append("\n".toString());
			for(int i = 0; i < player1.length; i++){
				String val1 = Integer.toString(player1[i]);
				String val2 = Integer.toString(player2[i]);
				csvWrite.append(val1);
				csvWrite.append(",".toString());
				csvWrite.append(val2);
				csvWrite.append("\n".toString());
			}
			System.out.println("CSV file was created successfully");

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				csvWrite.flush();
				csvWrite.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter");
				e.printStackTrace();
			}

		}
	}
	public void WriteToCSV(String location, String name) {
		FileWriter csvWrite = null;
		try {
			csvWrite = new FileWriter(location);
			csvWrite.append(name);
			csvWrite.append("\n".toString());
			for (Individual i : population) {
				for (double g : i.getGenome()) {
					String l = Double.toString(g);
					csvWrite.append(l);
					csvWrite.append(",".toString());
				}
				csvWrite.append("\n".toString());
			}
			csvWrite.append("\n".toString());
			System.out.println("CSV file was created successfully");

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				csvWrite.flush();
				csvWrite.close();
			} catch (IOException e) {
				System.out.println("Error while flushing/closing fileWriter");
				e.printStackTrace();
			}

		}
	}
	public ArrayList<Individual> ReadFromCSV(String location){
		ArrayList<Individual> loadedPopulation = new ArrayList<Individual>();
		BufferedReader br = null;
		String line ="";
		String split = ",";
		boolean firstLine = true;
		try {
			br = new BufferedReader(new FileReader(location));
            try {
				while ((line = br.readLine()) != null) {
					if(firstLine){
						firstLine = false;
					}else{
						   String[] data = line.split(split);
						   double[] values = new double[data.length];
						   for(int i = 0; i < data.length; i++){
							   //System.out.println(data[i]);
							   try {
								   double number = Double.valueOf(data[i]);
								   values[i] = number;
								   } catch(Exception e) {
									   
							       }
						   }
						   Individual in = new Individual(values);
						   loadedPopulation.add(in);
					}
				}
				System.out.println("File successfully read");
			} catch (IOException e) {
				System.out.println("IO exception from file: " + location);
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			System.out.println("Could not read from file: " + location);
			e.printStackTrace();
		}	
		return loadedPopulation;	
	}

}
