import java.awt.Color;

public class CounterStack implements Cloneable{
	protected int top = 0;
	protected final int maxSize = 15;
	protected Counter[] stack = new Counter[maxSize];

	public CounterStack() {

	}

	public void Push(Counter c) {
		if(top < maxSize){
			stack[top++] = c;
		}
	}

	public Counter Pop() {
		return stack[--top];
	}

	public boolean IsFull() {
		return top == maxSize;
	}

	public boolean IsEmpty() {
		return top == 0;
	}
	public int Size(){
		return top; 
	}
	public Color getCounterColour(){
		return stack[0].getColour();
	}
	@Override
	protected CounterStack clone() throws CloneNotSupportedException {
		CounterStack clone = (CounterStack)super.clone();
		clone.stack = new Counter[maxSize];
		clone.top = 0;
		int count = 0;
		for(Counter c : this.stack){
			while(count < top){
				Counter cloneC = (Counter)c.clone();
				clone.Push(cloneC);
				count++;
			}

		}
		return clone;
	}

}
