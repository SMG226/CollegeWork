/*import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
*/
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Game{
	private JFrame frame;
	private JPanel panel;
	public Game(int[] c){
		initGUI(c);
	}
	private void initGUI(int[] c){
		Population pop = new Population(c[0], c[1], 10, 0.005,c[2]);
		pop.initPopulation();
		pop.run();
		
		
	}
	
}
