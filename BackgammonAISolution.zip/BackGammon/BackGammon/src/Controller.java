
public class Controller {

	public static void main(String[] args) {
		int values[] = new int[3];
		values[0] = Integer.parseInt(args[0]);//generations
		values[1] = Integer.parseInt(args[1]);//population size
		values[2] = Integer.parseInt(args[2]);//selection
		Game g = new Game(values);
	}

}
