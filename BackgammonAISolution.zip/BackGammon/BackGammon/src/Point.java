import java.awt.Color;

public class Point extends CounterStack implements Cloneable{
	private int ID;
	private Color colour;
	private int[] xLocation;
	private int[] yLocation;
	private boolean isAvailable;

	public Point(int i, Color c, int[]x, int[]y) {
		this.ID = i;
		this.colour = c;
		this.xLocation = x;
		this.yLocation = y;
	}
	
	public int getID() {
		return ID;
	}

	public Color getColour() {
		return colour;
	}
	public void setColour(Color c){
		this.colour = c;
	}
	
	public int[] getxLocation() {
		return xLocation;
	}
	
	public int[] getyLocation() {
		return yLocation;
	}
	public boolean isAvailable() {
		return isAvailable;
	}

	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	@Override
	protected Point clone() throws CloneNotSupportedException {
		Point clone = (Point)super.clone();
		clone.stack = new Counter[maxSize];
		clone.top = 0;
		int count = 0;
		for(Counter c : super.stack){
			while(count < top){
				Counter cloneC = (Counter)c.clone();
				clone.Push(cloneC);
				count++;
			}

		}
		
		return clone;
	}

}
