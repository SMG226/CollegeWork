import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Arrays;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GameBoard extends JPanel implements MouseListener, ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Point[] points = new Point[26];
	private Counter[] counters = new Counter[30];
	private Counter selectedCounter = new Counter();
	private JButton rollButton = new JButton();
	private int[] dice = new int[4];
	private JLabel diceLabel = new JLabel();
	private CounterStack blackBarStack = new CounterStack();
	private CounterStack greyBarStack = new CounterStack();
	private int oPoint;
	private MovementGenerator blackMG;
	private MovementGenerator greyMG;
	private Boolean playerOneTurn = null;
	private boolean finished = false;
	private boolean automated = false;
	

	public GameBoard(double[] player1, double[] player2, boolean a) {
		this.addMouseListener(this);
		double[] play1 = new double[10];
		double[] play2 = new double[10];
		this.automated  = a;
		for(int i = 0; i < 10; i++){
			play1[i] = player1[i];
			play2[i] = player2[i];
		}
		blackMG = new MovementGenerator(Color.black,play1);
		greyMG = new MovementGenerator(Color.gray,play2);
		// Bottom of Board
		points[0] = new Point(0, Color.RED, new int[] { 0, 0, 0 }, new int[] { 0, 0, 0 });
		points[1] = new Point(1, Color.GREEN, new int[] { 575, 600, 550 }, new int[] { 200, 355, 355 });
		points[2] = new Point(2, Color.RED, new int[] { 525, 550, 500 }, new int[] { 200, 355, 355 });
		points[3] = new Point(3, Color.GREEN, new int[] { 475, 500, 450 }, new int[] { 200, 355, 355 });
		points[4] = new Point(4, Color.RED, new int[] { 425, 450, 400 }, new int[] { 200, 355, 355 });
		points[5] = new Point(5, Color.GREEN, new int[] { 375, 400, 350 }, new int[] { 200, 355, 355 });
		points[6] = new Point(6, Color.RED, new int[] { 325, 350, 300 }, new int[] { 200, 355, 355 });
		points[7] = new Point(7, Color.GREEN, new int[] { 275, 300, 250 }, new int[] { 200, 355, 355 });
		points[8] = new Point(8, Color.RED, new int[] { 225, 250, 200 }, new int[] { 200, 355, 355 });
		points[9] = new Point(9, Color.GREEN, new int[] { 175, 200, 150 }, new int[] { 200, 355, 355 });
		points[10] = new Point(10, Color.RED, new int[] { 125, 150, 100 }, new int[] { 200, 355, 355 });
		points[11] = new Point(11, Color.GREEN, new int[] { 75, 100, 50 }, new int[] { 200, 355, 355 });
		points[12] = new Point(12, Color.RED, new int[] { 25, 50, 0 }, new int[] { 200, 355, 355 });
		// Top of Board
		points[13] = new Point(13, Color.GREEN, new int[] { 25, 50, 0 }, new int[] { 155, 0, 0 });
		points[14] = new Point(14, Color.RED, new int[] { 75, 100, 50 }, new int[] { 155, 0, 0 });
		points[15] = new Point(15, Color.GREEN, new int[] { 125, 150, 100 }, new int[] { 155, 0, 0 });
		points[16] = new Point(16, Color.RED, new int[] { 175, 200, 150 }, new int[] { 155, 0, 0 });
		points[17] = new Point(17, Color.GREEN, new int[] { 225, 250, 200 }, new int[] { 155, 0, 0 });
		points[18] = new Point(18, Color.RED, new int[] { 275, 300, 250 }, new int[] { 155, 0, 0 });
		points[19] = new Point(19, Color.GREEN, new int[] { 325, 350, 300 }, new int[] { 155, 0, 0 });
		points[20] = new Point(20, Color.RED, new int[] { 375, 400, 350 }, new int[] { 155, 0, 0 });
		points[21] = new Point(21, Color.GREEN, new int[] { 425, 450, 400 }, new int[] { 155, 0, 0 });
		points[22] = new Point(22, Color.RED, new int[] { 475, 500, 450 }, new int[] { 155, 0, 0 });
		points[23] = new Point(23, Color.GREEN, new int[] { 525, 550, 500 }, new int[] { 155, 0, 0 });
		points[24] = new Point(24, Color.RED, new int[] { 575, 600, 550 }, new int[] { 155, 0, 0 });
		points[25] = new Point(25, Color.GREEN, new int[] { 0, 0, 0 }, new int[] { 0, 0, 0 });
		
		// Create Counters
		for (int i = 0; i < 30; i++) {
			if (i < 15)
				counters[i] = new Counter(i, true);
			else
				counters[i] = new Counter(i, false);

		}
		// Add counters
		points[1].Push(counters[0]);
		points[1].Push(counters[1]);
		points[6].Push(counters[15]);
		points[6].Push(counters[16]);
		points[6].Push(counters[17]);
		points[6].Push(counters[18]);
		points[6].Push(counters[19]);
		points[8].Push(counters[20]);
		points[8].Push(counters[21]);
		points[8].Push(counters[22]);
		points[12].Push(counters[2]);
		points[12].Push(counters[3]);
		points[12].Push(counters[4]);
		points[12].Push(counters[5]);
		points[12].Push(counters[6]);
		points[13].Push(counters[23]);
		points[13].Push(counters[24]);
		points[13].Push(counters[25]);
		points[13].Push(counters[26]);
		points[13].Push(counters[27]);
		points[17].Push(counters[7]);
		points[17].Push(counters[8]);
		points[17].Push(counters[9]);
		points[19].Push(counters[10]);
		points[19].Push(counters[11]);
		points[19].Push(counters[12]);
		points[19].Push(counters[13]);
		points[19].Push(counters[14]);
		points[24].Push(counters[28]);
		points[24].Push(counters[29]);

		// Set button
		rollButton.setBounds(630, 20, 80, 40);
		rollButton.setText("Roll");
		rollButton.addActionListener(this);
		this.setLayout(null);
		this.add(rollButton);
		//set dice text
		diceLabel.setBounds(720, 20, 80, 40);
		diceLabel.setText("Dice Rolls");
		this.add(diceLabel);

	}

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		//Draw points
		Graphics2D g2 = (Graphics2D) g;
		Polygon p;
		g.setColor(Color.LIGHT_GRAY);
		g.fillRect(0, 0, 600, 355);
		for (Point i : points) {
			g.setColor(i.getColour());
			p = new Polygon(i.getxLocation(), i.getyLocation(), 3);
			g2.fillPolygon(p);
		}
		//Draw line down middle
		g.setColor(Color.black);
		g.drawLine(300, 355, 300, 0);
		//Set available points to blue
		if(points[0].isAvailable() || points[25].isAvailable()){
			g.setColor(Color.BLUE);
		}else{
			g.setColor(Color.WHITE);
		}		
		g.fillRect(600, 0, 20, 355);//End points
		g.setColor(Color.WHITE);
		g.fillRect(0, 355, 600, 20);//Bar
		for (Point i : points) {// Draw Counters
			if(i != points[25] && i != points[0]){
				if (i.IsEmpty() != true) {
					if (i.getID() < 13) {
						int x = i.getxLocation()[1] - 35;
						int y = i.getyLocation()[1] - 25;
						for (int j = 0; j < i.Size(); j++) {
							g.setColor(i.getCounterColour());
							g.fillOval(x, y, 25, 25);
							y -= 25;
						}
					} else {
						int x = i.getxLocation()[1] - 35;
						int y = i.getyLocation()[1];
						for (int j = 0; j < i.Size(); j++) {
							g.setColor(i.getCounterColour());
							g.fillOval(x, y, 25, 25);
							y += 25;
						}
					}
				}
			}else{
				int y;
				if(i == points[25]){
					y = 2;
					g.setColor(Color.black);
					for(int j = 0; j < i.Size(); j++){
						g.fillRect(602, y, 17, 9);
						y +=10;
					}
				}else{
					y = 350;
					g.setColor(Color.gray);
					for(int j = 0; j < i.Size(); j++){
						g.fillRect(602, y, 17, 9);
						y -=10;
					}
				}				
			}

		}
		int X = 290;
		int Y = 357;
		for(int i = 0; i < blackBarStack.Size(); i++){
			g.setColor(Color.BLACK);
			g.fillRect(X, Y, 9, 17);
			X-=10;
		}
		X = 301;
		for(int i = 0; i < greyBarStack.Size(); i++){
			g.setColor(Color.GRAY);
			g.fillRect(X, Y, 9, 17);
			X+=10;
		}
	}

	private void availablePoints(Point p){//checks available points from a given point
		int pointLocation = p.getID();
		p.setColour(Color.BLUE);
		p.setAvailable(true);
		oPoint = pointLocation;
		selectedCounter = p.Pop();
		if(selectedCounter.getColour()== Color.black){
			for(Point ps : points){
				for(int d : dice){
					if(ps.getID() ==  d+pointLocation && d != 0 && ps.getID() < 25){
						if(ps.IsEmpty()== false && (ps.getCounterColour() == selectedCounter.getColour() || ps.Size() <= 1)){
							ps.setColour(Color.blue);
							ps.setAvailable(true);
						}else if(ps.IsEmpty()== true){
							ps.setColour(Color.blue);
							ps.setAvailable(true);
						}
					}
					if(blackMG.bearOffStage(points, selectedCounter.getColour())){
						if(25 <=  d+pointLocation && d != 0){
							points[25].setAvailable(true);
						}
					}
				}
			}
		}else{
			for(Point ps : points){
				for(int d : dice){
					if(ps.getID() ==  pointLocation -d && d != 0 && ps.getID() > 0){
						if(ps.IsEmpty()== false && (ps.getCounterColour() == selectedCounter.getColour() || ps.Size() <= 1)){
							ps.setColour(Color.blue);
							ps.setAvailable(true);
						}else if(ps.IsEmpty()== true){
							ps.setColour(Color.blue);
							ps.setAvailable(true);
						}
					}
					if(greyMG.bearOffStage(points, selectedCounter.getColour())){
						if(0 >=  pointLocation - d && d != 0){
							points[0].setAvailable(true);
						}
					}
				}
			}
		}
		repaint();
	}
	private void moveChecker(Point p, int d){// move counter... used by MG
		if(p.IsEmpty()== false && (p.getCounterColour() != selectedCounter.getColour() && p.Size() > 1)){
			return;
		}else if(p.IsEmpty()== false && (p.getCounterColour() != selectedCounter.getColour() && p.Size() <= 1)){
			if(p.getCounterColour()==Color.black){
				blackBarStack.Push(p.Pop());
			}else{
				greyBarStack.Push(p.Pop());	
			}
		}
		for(int i = 0; i < dice.length; i++){
			if(dice[i] == d){
				dice[i] =0;
				break;
			}
		}
		diceLabel.setText(dice[0] + " " + dice[1] + " " + dice[2] + " " + dice[3]);
		for(Point ps : points){
			if(ps.isAvailable()){
				ps.setAvailable(false);
				if(ps.getID()% 2 == 0){
					ps.setColour(Color.red);
				}else{
					ps.setColour(Color.green);
				}
			}
		}
		p.Push(selectedCounter);
		selectedCounter = new Counter();
	
		repaint();
	}
	private void moveChecker(Point p){//Move counter used by player
		if(p.IsEmpty()== false && (p.getCounterColour() != selectedCounter.getColour() && p.Size() > 1)){
			return;
		}else if(p.IsEmpty()== false && (p.getCounterColour() != selectedCounter.getColour() && p.Size() <= 1)){
			if(p.getCounterColour()==Color.black){
				blackBarStack.Push(p.Pop());
			}else{
				greyBarStack.Push(p.Pop());	
			}
		}
		for(int i = 0; i < dice.length ; i++){
			int d = dice[i];
			if(selectedCounter.getColour() == Color.gray && p.getID() == oPoint - d){
				dice[i] = 0;				
				break;
			}else if(selectedCounter.getColour() == Color.black && p.getID() == oPoint + d){
				dice[i] = 0;				
				break;
			}
		}
		diceLabel.setText(dice[0] + " " + dice[1] + " " + dice[2] + " " + dice[3]);
		for(Point ps : points){
			if(ps.isAvailable()){
				ps.setAvailable(false);
				if(ps.getID()% 2 == 0){
					ps.setColour(Color.red);
				}else{
					ps.setColour(Color.green);
				}
			}
		}
		if(points[25].Size() == 15 || points[0].Size() == 15){
			System.out.println("FINISHED");
		}
		p.Push(selectedCounter);
		selectedCounter = new Counter();
		//System.out.println("From: " + oPoint + "To: " + p.getID());
		repaint();
	}
	private void movements(){
		if(!finished){
			Movement m = new Movement(0,0,0);
			for(int i  = 0; i < dice.length ; i++){
				if(playerOneTurn){
					m = blackMG.generateMovement(dice, points, blackBarStack);
				}else{
					m = greyMG.generateMovement(dice, points, greyBarStack);
				}
				if(m != null){
					if(m.getFrom() == 40){
						selectedCounter = greyBarStack.Pop();
					}else if(m.getFrom() == 30){
						selectedCounter = blackBarStack.Pop();
					}else{
						selectedCounter = points[m.getFrom()].Pop();
					}
					moveChecker(points[m.getTo()] , m.getDice());
				}else{
					break;
				}
			}
		}		
	}
	private void diceRolls(){
		dice[0] = (int) (Math.random() * 6 + 1);
		dice[1] = (int) (Math.random() * 6 + 1);
		if(playerOneTurn == null){//find first player
			while(dice[0] == dice[1]){
				dice[0] = (int) (Math.random() * 6 + 1);
				dice[1] = (int) (Math.random() * 6 + 1);
			}
			if(dice[0] > dice[1]){
				playerOneTurn = true;
			}else{
				playerOneTurn = false;
			}
		}else{//All other dice rolls
			if (playerOneTurn) {
				playerOneTurn = false;
			} else {
				playerOneTurn = true;
			}
			if (dice[0] == dice[1]) {
				dice[2] = dice[0];
				dice[3] = dice[0];
			} else {
				dice[2] = 0;
				dice[3] = 0;
			}
		}
		diceLabel.setText(dice[0] + " " + dice[1] + " " + dice[2] + " " + dice[3]);
		//System.out.println(dice[0] + " " + dice[1] + " " + dice[2] + " " + dice[3] + " " + "Player One Turn:" + playerOneTurn);
		if(automated || !playerOneTurn){
			movements();
		}		
		repaint();
	}
	public int[] calcFinished(){
		
		while(!finished){
			diceRolls();
			if(points[25].Size() == 15 || points[0].Size() == 15){				
				finished = true;
				break;
			}
		}
		if(finished){
			//System.out.println("FINISHED");
			//System.out.println(points[0].Size() + " " + points[25].Size());
			repaint();
			int blackFS = blackMG.distanceFromEnd(points, blackBarStack);
			int grayFS = greyMG.distanceFromEnd(points, greyBarStack);
			int[] finalScore = new int[2];
			finalScore[0] = blackFS;
			finalScore[1] = grayFS;
			return finalScore;
		}else{
			return null;
		}

	}
	@Override
	public void mouseClicked(MouseEvent e) {//Click location verification
		int x = e.getX();
		int y = e.getY();
		int[] loc = {0,0,0};
		if(playerOneTurn != null){
			if(playerOneTurn == true && blackBarStack.Size() >0){
				if(y > 355 && y < 375 && x < 600){//Bar					
					Point c = new Point(0, Color.blue,loc,loc );
					c.Push(blackBarStack.Pop());
					availablePoints(c);
				}
			}else if(playerOneTurn == false && greyBarStack.Size() > 0){
				if(y > 355 && y < 375 && x < 600){//Bar
					Point c = new Point(25, Color.blue,loc,loc );
					c.Push(greyBarStack.Pop());
					availablePoints(c);
				}
			}else{
				if (selectedCounter.getID() == 500) {
					for (Point p : points) {
						if ((x <= p.getxLocation()[1]) && (x >= p.getxLocation()[2])
								&& (y <= p.getyLocation()[0] && p.getyLocation()[0] <= 155)) {
							if (p.IsEmpty() == false) {
								if((p.getCounterColour() == Color.BLACK && playerOneTurn)||(p.getCounterColour() != Color.BLACK&& !playerOneTurn)){
									availablePoints(p);
								}
							}
						}
						if ((x <= p.getxLocation()[1]) && (x >= p.getxLocation()[2])
								&& (y >= p.getyLocation()[0] && p.getyLocation()[0] >= 200 && y <355)) {
							if (p.IsEmpty() == false) {
								if((p.getCounterColour() == Color.BLACK && playerOneTurn)||(p.getCounterColour() != Color.BLACK&& !playerOneTurn)){
									availablePoints(p);
								}
							}
						}
					}
				} else {
					for (Point p : points) {
						if ((x <= p.getxLocation()[1]) && (x >= p.getxLocation()[2])
								&& (y <= p.getyLocation()[0] && p.getyLocation()[0] <= 155)) {
							if (p.IsFull() == false && p.isAvailable()) {
								moveChecker(p);
							}
						}
						if ((x <= p.getxLocation()[1]) && (x >= p.getxLocation()[2])
								&& (y >= p.getyLocation()[0] && p.getyLocation()[0] >= 200 && y < 355)) {
							if (p.IsFull() == false && p.isAvailable()) {
								moveChecker(p);
							}
						}
						if(x > 600 && x < 620 && y < 355){//Bear checker off
							if(playerOneTurn){
								if(points[25].isAvailable()){
									moveChecker(points[25]);
								}
							}else{
								if(points[0].isAvailable()){
									moveChecker(points[0]);
								}
							}
						}
					}
				}
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {

	}

	@Override
	public void mouseExited(MouseEvent e) {

	}

	@Override
	public void mousePressed(MouseEvent e) {

	}

	@Override
	public void mouseReleased(MouseEvent e) {

	}

	@Override
	public void actionPerformed(ActionEvent action) {
		diceRolls();
	}
}
