import java.util.Random;

public class Individual {
	private double[] genome;
	private float fitness;
	private Random rng = new Random();
	public Individual(double[] genes){
		genome = new double[genes.length];
		for(int i = 0; i < genes.length; i++){
			genome[i] = genes[i];
		}
	}
	public Individual(int length){
		genome = new double[length];
		for(int i = 0; i < length; i++){
			genome[i] = rng.nextDouble();
		}
	}
	public void mutate(double mutationRate){
		for(int i = 0; i < genome.length; i++){
			if(rng.nextFloat() < mutationRate){
				genome[i] = rng.nextDouble();
			}
		}
	}
	public Individual Crossover(Individual partner){
		int crossoverPoint = rng.nextInt(genome.length);
		double[] newGenome = new double[genome.length];
		for(int i = 0; i < genome.length; i++){
			if(i < crossoverPoint){
				newGenome[i] = genome[i];
			}else{
				newGenome[i] = partner.genome[i];
			}
		}
		Individual child = new Individual(newGenome);
		return child;
	}
	public void setFitness(float val){
		this.fitness = val;
	}
	public float getFitness(){
		return fitness;
	}
	public void setGenome(double[] vals){
		this.genome = vals;
	}
	public double[] getGenome(){
		return genome;
	}

}
