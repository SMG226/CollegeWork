import java.awt.Color;

public class Counter implements Cloneable{
	private int ID;
	private Color colour;
	private boolean playerTeam;
	/**
	 * @param c
	 * Constructor
	 * 
	 */
	public Counter(int ID,boolean team){
		this.ID = ID;
		this.playerTeam = team;
		if(team == true)
			this.colour = Color.BLACK;
		else
			this.colour = Color.GRAY;
	}
	
	@Override
	protected Counter clone() throws CloneNotSupportedException {
		Counter clone = (Counter)super.clone();
		//clone.colour = colour;
		return clone;
	}

	public Counter() {
		this.ID = 500;
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public Color getColour() {
		return colour;
	}
	

	public void setColour(Color colour) {
		this.colour = colour;
	}
	public boolean getTeam(){
		return playerTeam;
		
	}
}
