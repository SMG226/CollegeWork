import java.awt.Color;
import java.util.ArrayList;

public class MovementGenerator {
	private ArrayList<Movement> movementList;
	private Color side;
	private double[] weight;

	public MovementGenerator(Color Side) {
		this.side = Side;
		weight = new double[10];
		for (int i = 0; i < 10; i++) {
			weight[i] = 1;
		}
	}

	public MovementGenerator(Color Side, double[] weights) {
		this.side = Side;
		weight = new double[10];
		for (int i = 0; i < 10; i++) {
			weight[i] = weights[i];
		}
	}

	public Movement generateMovement(int[] dice, Point[] points, CounterStack bar) {
		movementList = new ArrayList<Movement>();
		Movement move;
		// Bring Counters from Bar
		// Has priority over other movements
		if (bar.IsEmpty() == false) {
			Movement barMove;
			for (int i : dice) {
				if (i != 0) {
					if (side == Color.black) {
						barMove = new Movement(30, i , i);
					} else {
						barMove = new Movement(40, (25 - i), i);
					}
					if(points[barMove.getTo()].IsEmpty() == false && (points[barMove.getTo()].getCounterColour() == side||points[barMove.getTo()].Size() <= 1)){
						movementList.add(barMove);
					}else if(points[barMove.getTo()].IsEmpty() == true){
						movementList.add(barMove);
					}
				}
			}
			if(movementList.size() > 0){
				move = movementList.get(0);
			}else{
				move = null;
			}
		} else {
			for (Point p : points) {
				if (p.IsEmpty() == false && p.getCounterColour() == side) {
					int from = p.getID();
					for (int i : dice) {
						if (i != 0) {
							Point toPoint = points[from];
							Movement m;
							if (side == Color.black) {
								if (from + i < 25) {
									toPoint = points[from + i];
								}else if (bearOffStage(points, side) == true && from + i >= 25) {
									toPoint = points[25];
								}else{
									toPoint = null;
								}
							} else {
								if (from - i > 0) {
									toPoint = points[from - i];
								} else if (bearOffStage(points, side) == true && from - i <= 0) {
									toPoint = points[0];
								}else{
									toPoint = null;
								}
							}
							if(toPoint != null){

								if(toPoint.IsEmpty() == false && (toPoint.getCounterColour() == p.getCounterColour()||toPoint.Size() <= 1)){
									m = new Movement(from, toPoint.getID(),i);
									movementList.add(m);
								}else if(toPoint.IsEmpty() == true){
									m = new Movement(from, toPoint.getID(),i);
									movementList.add(m);
								}
							}
						}
					}
				}
			}
			// removes all values which dont move counters.
			for(int i = 0; i < movementList.size(); i++){
				if(movementList.get(i).getDifference() == 0){
					movementList.remove(i);
				}
			}
			for (Movement m : movementList) {
				boardValue(points, m, bar);		
			}
			if(movementList.size() > 0){
				move = getHighest(movementList);
				//System.out.println(">>> " + move);
				//System.out.println("//////////");
			}else{
				move = null;
			}		
		}		
		return move;
	}

	public boolean bearOffStage(Point[] points, Color side) {
		//Tests for bear off stage
		if (side == Color.BLACK) {
			for (int i = 1; i < 19; i++) {
				if (points[i].IsEmpty() == false && points[i].getCounterColour() == side) {
					return false;
				}
			}
		} else {
			for (int i = 24; i > 6; i--) {
				if (points[i].IsEmpty() == false && points[i].getCounterColour() == side) {
					return false;
				}
			}
		}
		return true;

	}

	public void boardValue(Point[] oPoints, Movement movement, CounterStack originalBar) {
		double evalFunction;
		int bearOffs;
		int safeCheckers;
		int distanceFromEnd;//
		int prime;
		int moreThanFive;//
		int innerBoard;
		int hitEnemy = 0;
		int outProximity;//
		int homeBoardCount;
		int distance;
		Point[] points = new Point[oPoints.length];

		for (int i = 0; i < oPoints.length; i++) {
			try {
				points[i] = oPoints[i].clone();
			} catch (CloneNotSupportedException e) {
				e.printStackTrace();
			}
			//System.out.println(points[i].getID() + " : " + points[i].Size());
		}
		
		CounterStack bar = null;
		CounterStack opponentBar = new CounterStack();
		//clone objects to test movements
		try {
			bar = originalBar.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		// Create new board state
		if ((points[movement.getFrom()].IsEmpty() == false)
				&& (points[movement.getFrom()].getCounterColour() == side)) {
			if (points[movement.getTo()].IsEmpty() == false && points[movement.getTo()].getCounterColour() != side) {
				opponentBar.Push(points[movement.getTo()].Pop());
				hitEnemy = 1;
			}
			if (movement.getFrom() == 30 || movement.getFrom() == 40) {//???
				points[movement.getTo()].Push(bar.Pop());
			} else {
				points[movement.getTo()].Push(points[movement.getFrom()].Pop());
			}
			//Make calculations based off new board state
			bearOffs = numberOfBearOffs(points);
			safeCheckers = numberOfSafeCheckers(points);
			distanceFromEnd = distanceFromEnd(points, bar);
			prime = existanceOfPrime(points);
			moreThanFive = greaterThanFive(points);
			innerBoard = innerBoard(points);
			outProximity = moveApart(points);
			homeBoardCount = homeBoard(points);
			distance = boardWidth(points);
			evalFunction = ((bearOffs * weight[0]) + (safeCheckers * weight[1]) + (prime * weight[2])
					+ (innerBoard * weight[3]) + (hitEnemy * weight[4]))
					- ((distanceFromEnd * weight[5]) + (moreThanFive * weight[6]) + (outProximity * weight[7]) + (homeBoardCount * weight[8]) + (distance * weight[9]));
			movement.setEvaluation(evalFunction);
			//System.out.println(evalFunction);
		} else {
			System.out.println("Error in board evaluation, incorrect side selected from movement list");// throw
																										// error
		}
	}

	private int numberOfBearOffs(Point[] points) {
		int bearNum = 0;
		if (side == Color.black) {
			bearNum = points[25].Size();
		} else {
			bearNum = points[0].Size();
		}
		return bearNum;

	}

	private int numberOfSafeCheckers(Point[] points) {// Counts the number of safe checkers

		int counters = 0;
		for (Point p : points) {
			if (p.Size() >= 2 && p.getCounterColour() == side) {
				counters = counters += p.Size();
			}
			
		}
		return counters;
	}

	public int distanceFromEnd(Point[] points, CounterStack bar) {
		int totalDistance = 375;
		for (Point p : points) {
			
			if (p.IsEmpty() == false && p.getCounterColour() == side) {
				if(side == Color.black){
					totalDistance = totalDistance - (p.getID() * p.Size());
				}else{
					int to = (25 - p.getID());
					totalDistance = totalDistance - (to * p.Size());
				}
			
			}
		}
		for (int i = 0; i < bar.Size() ; i++) {
			totalDistance += 25;
		}
		return totalDistance;
	}

	private int existanceOfPrime(Point[] points) {
													
		boolean prime = false;
		int count = 0;
		for (Point p : points) {
			if (p.Size() >= 2 && p.getCounterColour() == side && p.getID() != 25 && p.getID() != 0) {
				if (points[p.getID() + 1].Size() >= 2) {
					count = count + 1;
				} else {
					count = 0;
				}
			}
			if (count == 6) {
				prime = true;
				break;
			}
		}
		if (prime) {
			return 1;
		} else {
			return 0;
		}
	}

	private int greaterThanFive(Point[] points) {
		int count = 0;
		for (Point p : points) {
			if (p.Size() > 5 && p.getCounterColour() == side && p != points[25] && p != points[0]) {
				count++;
			}
		}
		return count;
	}

	private int innerBoard(Point[] points) {
		int count = 0;
		for (Point p : points) {
			if (p.IsEmpty() == false && side == p.getCounterColour()) {
				if (side == Color.black && p.getID() > 18 && p.getID() < 26) {
					count = count + p.Size();
				} else if (side == Color.gray && p.getID() < 7) {
					count = count + p.Size();
				}
			}
		}
		return count;
	}

	private int moveApart(Point[] points) {
		int count = 0;
		boolean proxTracker;
		for (Point p : points) {
			proxTracker = false;
			if (p.IsEmpty() == false && p.getCounterColour() == side) {
				for (int i = 0; i < 6; i++) {
					if (points[p.getID() + i].IsEmpty() == false && points[p.getID() + i].getCounterColour() == side) {
						proxTracker = true;
						i = 6;
					}
				}
				if (proxTracker == false) {
					count++;
				}
			}
		}
		return count;
	}
	private int homeBoard(Point[] points){
		int count = 0;
		for (Point p : points) {
			if (p.IsEmpty() == false && side == p.getCounterColour()) {
				if (side == Color.gray && p.getID() > 18 && p.getID() < 25) {
					count = count + p.Size();
				} else if (side == Color.black && p.getID() < 7) {
					count = count + p.Size();
				}
			}
		}
		return count;
	}
	private int boardWidth(Point[] points){
		int count = 0;
		int iPoint = 0;
		boolean found = false;
		for(Point p : points){
			if(p.IsEmpty() == false && p.getCounterColour() == side){
				if(!found && p.getID() > 0){
					iPoint = p.getID();
					found = true;
				}else if(found && p.getID() < 25){
					count = p.getID();
				}
			}
		}
		count = count - iPoint;
		return count;
	}
	@SuppressWarnings("unused")
	private void listSort(ArrayList<Movement> a){
		for(int i =1; i <a.size(); ++i){			
			Movement value = a.get(i);
			System.out.println(value + " >>> " + value.getEvaluation());
			int j =i -1;
			while(j >=0 && !value.CompareTo(a.get(j))){
				a.set(j +1, a.get(j));
				j = j -1;
			}
			a.set(j + 1, value);
		}
	}
	private Movement getHighest(ArrayList<Movement> a){
		Movement test = new Movement(0, 0 , 0);
		test.setEvaluation(-1000);
		for(Movement t : a){
			if(test.CompareTo(t)){
				test= t;
			}
		}
		return test;	
	}

}
