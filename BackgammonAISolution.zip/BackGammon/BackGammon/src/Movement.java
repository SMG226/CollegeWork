
public class Movement {
	private int from;
	private int to;
	private double evaluation;
	private int dice;
	public Movement(int from, int to, int dice){
		this.from = from;
		this.to = to;
		this.dice = dice;
	}
	public int getFrom() {
		return from;
	}
	public int getTo() {
		return to;
	}
	public int getDifference(){
		if(from > to){
			return (from - to);
		}else{
			return (to - from);
		}
	}
	public double getEvaluation() {
		return evaluation;
	}
	public void setEvaluation(double evaluation) {
		this.evaluation = evaluation;
	}
	public boolean CompareTo(Movement m){
		if(m.getEvaluation() <= evaluation){
			return false;
		}else{
			return true;
		}
	}
	public int getDice(){
		return dice;
	}
	@Override
	public String toString() {
		return "(from=" + from + ", to=" + to + ")";
	}
}
