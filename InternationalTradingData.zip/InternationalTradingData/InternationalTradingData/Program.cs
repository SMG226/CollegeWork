﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace InternationalTradingData
{
    static class Program
    {
        public static CountryTree<Country> Tree = new CountryTree<Country>();
        [STAThread]
        static void Main()
        {
            openFile(Tree);//Open file and load data into the tree
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new frmITD(Tree));//Run form pass in country tree
        }
        static void openFile(AVLTree<Country> tree)
        {
            const int MAX_LINES_FILE = 50000;
            string[] headers = new string[6];
            string[] AllLines = new string[MAX_LINES_FILE];
            AllLines = File.ReadAllLines("../../../countries.csv");
            foreach (string line in AllLines)
            {
                string name;
                decimal gdp;
                decimal inflation;
                decimal trade;
                int hdi;
                LinkedList<string> partners = new LinkedList<string>();
                if (line.StartsWith("Country"))
                {
                    headers = line.Split(',');
                }
                else
                {
                    string[] columns = line.Split(',');
                    name = columns[0];
                    gdp = decimal.Parse(columns[1]);
                    inflation = decimal.Parse(columns[2]);
                    trade = decimal.Parse(columns[3]);
                    hdi = int.Parse(columns[4]);

                    string[] tradepartners = columns[5].Split(';', '[', ']');
                    foreach (string partner in tradepartners)
                    {
                        if (partner != "")
                        {
                            partners.AddFirst(partner);
                        }
                    }
                    Country c = new Country(name, gdp, inflation, trade, hdi, partners);
                    Node<Country> node = new Node<Country>(c);
                    tree.InsertItem(node);
                    partners = null;
                    
                }

            }
        }
    }
    //Node. Used for storing countries
    public class Node< T> where T : IComparable
    {
        private T data;
        public Node<T> Left, Right;
        private int balanceFactor = 0;
        public int BalanceFactor
        {
            set { balanceFactor = value; }
            get { return balanceFactor; }
        }
        public Node(T item)
        {
            data = item;
            Left = null;
            Right = null;
        }
        public T Data
        {
            set { data = value; }
            get { return data; }
        }
        public int CompareTo(object other)
        {
            return data.CompareTo(other);
        }
    }

    //Country
    public class Country : IComparable
    {
        private string name;
        private decimal gdp;
        private decimal inflation;
        private decimal tradeBalance;
        private int hdi;
        private LinkedList<string> tradePartners = new LinkedList<string>();

        public Country(string Name, decimal GDP, decimal Inflation, decimal Trade, int HDI, LinkedList<string> TradePartners)
        {
            this.name = Name;
            this.gdp = GDP;
            this.inflation = Inflation;
            this.tradeBalance = Trade;
            this.hdi = HDI;
            this.tradePartners = TradePartners;
        }
        public string Name
        {
            set { name = value; }
            get { return name; }
        }
        public decimal GDP
        {
            set { gdp = value; }
            get { return gdp; }
        }
        public decimal Inflation
        {
            set { inflation = value; }
            get { return inflation; }
        }
        public decimal TradeBalance
        {
            set { tradeBalance = value; }
            get { return tradeBalance; }
        }
        public int HDI
        {
            set { hdi = value; }
            get { return hdi; }
        }
        public LinkedList<string> TradePartners
        {
            set { tradePartners = value; }
            get { return tradePartners; }
        }
        public bool ContainsTradePartner(string partner)
        {
            if (tradePartners.Contains(partner))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public int CompareTo(object other)
        {
            Country temp = (Country)other;
            return name.CompareTo(temp.name);
        }
    }
    //AVL TREE DATA STRUCTURE
    public class AVLTree<T> where T: IComparable
    {
        private Node<T> root;
        public AVLTree()
        {
            root = null;
        }
        public AVLTree(Node<T> node)
        {
            root = node;
        }
        protected Node<T> GetRoot()
        {
            return root;
        }
        public void InsertItem(Node<T> item)
        {
            insertItem(item, ref root);
        }

        private void insertItem(Node<T> item, ref Node<T> tree)
        {
            if (tree == null)
            {
                tree = item;
            }
            else if (item.CompareTo(tree.Data) < 0)
            {
                insertItem(item, ref tree.Left);
            }
            else if (item.CompareTo(tree.Data) > 0)
            {
                insertItem(item, ref tree.Right);
            }
            tree.BalanceFactor = height(tree.Left) - height(tree.Right);

            if (tree.BalanceFactor <= -2)
            {
                rotateLeft(ref tree);
            }
            if (tree.BalanceFactor >= 2)
            {
                rotateRight(ref tree);
            }
        }
        private void rotateLeft(ref Node<T> tree)
        {
            Node<T> oNode = tree;
            Node<T> nNode = tree.Right;
            if (tree.Right.BalanceFactor > 2)
            {
                rotateRight(ref tree.Right);
            }//double rotate                  

            oNode.Right = nNode.Left;
            nNode.Left = oNode;
            tree = nNode;

        }
        private void rotateRight(ref Node<T> tree)
        {
            Node<T> oNode = tree;
            Node< T> nNode = tree.Left;
            if (tree.Left.BalanceFactor > 2)
            {
                rotateLeft(ref tree.Left);
            }//double rotate
            oNode.Left = nNode.Right;
            nNode.Right = oNode;
            tree = nNode;

        }
        public int Height()
        {
            return height(root);
        }
        private int height(Node<T> tree)
        {
            if (tree == null)
            {
                return -1;
            }

            int lefth = height(tree.Left);
            int righth = height(tree.Right);

            if (lefth > righth)
            {
                return lefth + 1;
            }
            else
            {
                return righth + 1;
            }

        }
        public int Count()
        {
            int c = 1;
            return count(ref root, ref c);
        }
        private int count(ref Node<T> tree, ref int c)
        {
            if (tree.Left != null)
            {
                c++;
                count(ref tree.Left, ref  c);
            }
            if (tree.Right != null)
            {
                c++;
                count(ref tree.Right, ref c);
            }
            return c;

        }
        public Boolean Contains(T item)      
        {
            return contains(item, ref root);
        }
        private Boolean contains(T item, ref Node<T> tree)
        {
            if (tree == null)
            {
                return false;
            }
            else if (item.CompareTo(tree.Data) < 0)
            {
                return contains(item, ref tree.Left);
            }
            else if (item.CompareTo(tree.Data) > 0)
            {
                return contains(item, ref tree.Right);
            }
            else
            {
                return true;
            }
        }
        public Node<T> GetItem(T item)
        {
            return getItem(item, ref root);
        }
        private Node<T> getItem(T item, ref Node<T> tree)
        {
            if (tree == null)
            {
                return null;
            }
            else if (item.CompareTo(tree.Data) < 0)
            {
                return getItem(item, ref tree.Left);
            }
            else if (item.CompareTo(tree.Data) > 0)
            {
                return getItem(item, ref tree.Right);
            }
            else
            {
                return tree;
            }
        }
        public void UpdateItem(T oldCountry, Node<T> item)
        {
            updateItem(oldCountry, item, ref root);
        }
        private void updateItem(T oldCountry, Node<T> item, ref Node<T> tree)
        {
            if (tree == null)
            {
                return;
            }
            else if (oldCountry.CompareTo(tree.Data) < 0)
            {
                updateItem(oldCountry, item, ref tree.Left);
            }
            else if (oldCountry.CompareTo(tree.Data) > 0)
            {
                updateItem(oldCountry, item, ref tree.Right);
            }
            else
            {
                tree = item;
            }
        }
        public void RemoveItem(T item)
        {
            removeItem(item, ref root);
        }
        private void removeItem(T item, ref Node<T> tree)
        {
            if (tree != null)
            {

                if (item.CompareTo(tree.Data) < 0)
                {
                    removeItem(item, ref tree.Left);

                }
                else if (item.CompareTo(tree.Data) > 0)
                {
                    removeItem(item, ref tree.Right);
                }
                else if (item.CompareTo(tree.Data) == 0)//Item found
                {
                    if (tree.Left == null && tree.Right != null)
                    {
                        tree = tree.Right;
                    }
                    else if (tree.Right == null && tree.Left != null)
                    {
                        tree = tree.Left;
                    }
                    else if (tree.Right == null && tree.Left == null)//Item has no subtrees
                    {
                        tree = null;
                    }
                    else //Item has two subtrees
                    {
                        T newRoot = leastItem(tree.Right);
                        tree.Data = newRoot;
                        removeItem(newRoot, ref tree.Right);

                        root.BalanceFactor = height(root.Left) - height(root.Right);

                        if (root.BalanceFactor <= -2)
                        {
                            rotateLeft(ref root);
                        }
                        if (root.BalanceFactor >= 2)
                        {
                            rotateRight(ref root);
                        }
                    }
                }
            }
        }
        private T leastItem(Node<T> tree)
        {
            if (tree.Left == null)
            {
                return tree.Data;
            }
            else
            {
                return leastItem(tree.Left);
            }
        }
        public void InOrder(ref string buffer)
        {
            inOrder(root, ref buffer);
        }
        private void inOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                inOrder(tree.Left, ref buffer);
                buffer += tree.Data.ToString() + ',';
                inOrder(tree.Right, ref buffer);
            }
        }
        public void PreOrder(ref string buffer)
        {
            preOrder(root, ref buffer);
        }
        private void preOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                buffer += tree.Data.ToString() + ',';
                preOrder(tree.Left, ref buffer);
                preOrder(tree.Right, ref buffer);
            }
        }
        public void PostOrder(ref string buffer)
        {
            postOrder(root, ref buffer);
        }
        private void postOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                postOrder(tree.Left, ref buffer);
                postOrder(tree.Right, ref buffer);
                buffer += tree.Data.ToString() + ',';
            }
        }
    }
    //Class allows for country specific methods
    public class CountryTree<T> : AVLTree<T> where T: IComparable
    {
        public CountryTree(Node<T> node) : base(node)
        { 
            
        }
        public CountryTree(): base()
        {

        }
        public void AllPartners(ref string buffer, T item)
        {
            if (Contains(item) == true)
            {
                Node<T> n = GetItem(item);
                Country c1 = (Country)Convert.ChangeType(n.Data, typeof(Country), null);//Convert tree.data to country type to access the method
                foreach (String s in c1.TradePartners)
                {
                    buffer += s + ",";
                }
                allPartners(base.GetRoot(), c1, ref buffer);
            }
        }
        private void allPartners(Node<T> tree, Country item, ref string buffer)
        {
            if (tree != null)
            {
                allPartners(tree.Left, item , ref buffer);
                Country c2 = (Country)Convert.ChangeType(tree.Data, typeof(Country), null);//Convert tree.data to country type to access the method
                if (c2.ContainsTradePartner(item.Name) == true)//If contains name
                {
                    if (buffer.Contains(c2.Name) == false)
                    {
                        buffer += c2.Name + ",";
                    }

                }
                allPartners(tree.Right, item, ref buffer);
            }
        }
        public void InOrder(ref string buffer)
        {
            inOrder(base.GetRoot(), ref buffer);
        }
        private void inOrder(Node<T> tree, ref string buffer)
        {
            if (tree != null)
            {
                Country country = (Country)Convert.ChangeType(tree.Data, typeof(Country), null);
                inOrder(tree.Left, ref buffer);
                buffer += country.Name + ',';
                inOrder(tree.Right, ref buffer);
            }
        }
        //Allows for partial string searches
        public LinkedList<string> PartialSearch(T searchItem)
        {
            Country country = (Country)Convert.ChangeType(searchItem, typeof(Country), null);
            LinkedList<string> names = new LinkedList<string>();
            foreach(Node<T> name in ForEachInOrder())
            {
                Country countryData = (Country)Convert.ChangeType(name.Data, typeof(Country), null);
                if (countryData.Name.IndexOf(country.Name,StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    names.AddLast(countryData.Name);
                }
            }
            return names;
        }
        //Advised to use the example from earlier in the year for partial search.
        //So I used IEnumerable for an InOrder traversal.
        //Returns all the nodes in the tree InOrder
        public IEnumerable<Node<T>> ForEachInOrder()
        {
            return forEachInOrder(base.GetRoot());
        }
        private IEnumerable<Node<T>> forEachInOrder(Node<T> node)
        { 
            if(node != null)
            {
                if(node.Left != null)
                {
                    foreach(Node<T> nodeLeft in forEachInOrder(node.Left))
                    {
                        yield return nodeLeft;
                    }

                }
                yield return node;
                if(node.Right != null)
                {
                    foreach (var nodeRight in forEachInOrder(node.Right))
                    {
                        yield return nodeRight;
                    }
                }

            }
        }
    }

}