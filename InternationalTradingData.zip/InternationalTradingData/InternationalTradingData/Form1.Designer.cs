﻿namespace InternationalTradingData
{
    partial class frmITD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.txtGDP = new System.Windows.Forms.TextBox();
            this.txtInflation = new System.Windows.Forms.TextBox();
            this.txtTrade = new System.Windows.Forms.TextBox();
            this.rtbPartners = new System.Windows.Forms.RichTextBox();
            this.txtHDI = new System.Windows.Forms.TextBox();
            this.lblGDP = new System.Windows.Forms.Label();
            this.lblInflation = new System.Windows.Forms.Label();
            this.lblTrade = new System.Windows.Forms.Label();
            this.lblHDI = new System.Windows.Forms.Label();
            this.lblCountry = new System.Windows.Forms.Label();
            this.lblPartners = new System.Windows.Forms.Label();
            this.gpbCountyData = new System.Windows.Forms.GroupBox();
            this.btnSearch = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.gpbTradeData = new System.Windows.Forms.GroupBox();
            this.lblHighestGDP = new System.Windows.Forms.Label();
            this.lblBestTrade = new System.Windows.Forms.Label();
            this.rtbAllPartners = new System.Windows.Forms.RichTextBox();
            this.txtTradeCountry = new System.Windows.Forms.TextBox();
            this.btnTradeSearch = new System.Windows.Forms.Button();
            this.gpbAllNames = new System.Windows.Forms.GroupBox();
            this.lblHeightNum = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblNodes = new System.Windows.Forms.Label();
            this.rtbAllCountries = new System.Windows.Forms.RichTextBox();
            this.lblPartial = new System.Windows.Forms.Label();
            this.cmbPartial = new System.Windows.Forms.ComboBox();
            this.gpbCountyData.SuspendLayout();
            this.gpbTradeData.SuspendLayout();
            this.gpbAllNames.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtCountry
            // 
            this.txtCountry.Location = new System.Drawing.Point(90, 29);
            this.txtCountry.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(368, 26);
            this.txtCountry.TabIndex = 0;
            this.txtCountry.TextChanged += new System.EventHandler(this.txtCountry_TextChanged);
            // 
            // txtGDP
            // 
            this.txtGDP.Location = new System.Drawing.Point(172, 83);
            this.txtGDP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtGDP.Name = "txtGDP";
            this.txtGDP.Size = new System.Drawing.Size(148, 26);
            this.txtGDP.TabIndex = 1;
            // 
            // txtInflation
            // 
            this.txtInflation.Location = new System.Drawing.Point(172, 125);
            this.txtInflation.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtInflation.Name = "txtInflation";
            this.txtInflation.Size = new System.Drawing.Size(148, 26);
            this.txtInflation.TabIndex = 2;
            // 
            // txtTrade
            // 
            this.txtTrade.Location = new System.Drawing.Point(172, 166);
            this.txtTrade.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTrade.Name = "txtTrade";
            this.txtTrade.Size = new System.Drawing.Size(148, 26);
            this.txtTrade.TabIndex = 3;
            // 
            // rtbPartners
            // 
            this.rtbPartners.Location = new System.Drawing.Point(350, 83);
            this.rtbPartners.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rtbPartners.Name = "rtbPartners";
            this.rtbPartners.Size = new System.Drawing.Size(305, 210);
            this.rtbPartners.TabIndex = 4;
            this.rtbPartners.Text = "";
            // 
            // txtHDI
            // 
            this.txtHDI.Location = new System.Drawing.Point(172, 208);
            this.txtHDI.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtHDI.Name = "txtHDI";
            this.txtHDI.Size = new System.Drawing.Size(148, 26);
            this.txtHDI.TabIndex = 5;
            // 
            // lblGDP
            // 
            this.lblGDP.AutoSize = true;
            this.lblGDP.Location = new System.Drawing.Point(16, 94);
            this.lblGDP.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGDP.Name = "lblGDP";
            this.lblGDP.Size = new System.Drawing.Size(96, 20);
            this.lblGDP.TabIndex = 6;
            this.lblGDP.Text = "GDP growth";
            // 
            // lblInflation
            // 
            this.lblInflation.AutoSize = true;
            this.lblInflation.Location = new System.Drawing.Point(16, 135);
            this.lblInflation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInflation.Name = "lblInflation";
            this.lblInflation.Size = new System.Drawing.Size(66, 20);
            this.lblInflation.TabIndex = 7;
            this.lblInflation.Text = "Inflation";
            // 
            // lblTrade
            // 
            this.lblTrade.AutoSize = true;
            this.lblTrade.Location = new System.Drawing.Point(16, 177);
            this.lblTrade.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTrade.Name = "lblTrade";
            this.lblTrade.Size = new System.Drawing.Size(112, 20);
            this.lblTrade.TabIndex = 8;
            this.lblTrade.Text = "Trade Balance";
            // 
            // lblHDI
            // 
            this.lblHDI.AutoSize = true;
            this.lblHDI.Location = new System.Drawing.Point(16, 218);
            this.lblHDI.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblHDI.Name = "lblHDI";
            this.lblHDI.Size = new System.Drawing.Size(101, 20);
            this.lblHDI.TabIndex = 9;
            this.lblHDI.Text = "HDI Ranking";
            // 
            // lblCountry
            // 
            this.lblCountry.AutoSize = true;
            this.lblCountry.Location = new System.Drawing.Point(16, 34);
            this.lblCountry.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCountry.Name = "lblCountry";
            this.lblCountry.Size = new System.Drawing.Size(64, 20);
            this.lblCountry.TabIndex = 10;
            this.lblCountry.Text = "Country";
            // 
            // lblPartners
            // 
            this.lblPartners.AutoSize = true;
            this.lblPartners.Location = new System.Drawing.Point(355, 60);
            this.lblPartners.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPartners.Name = "lblPartners";
            this.lblPartners.Size = new System.Drawing.Size(152, 20);
            this.lblPartners.TabIndex = 11;
            this.lblPartners.Text = "Main Trade Partners";
            // 
            // gpbCountyData
            // 
            this.gpbCountyData.Controls.Add(this.cmbPartial);
            this.gpbCountyData.Controls.Add(this.lblPartial);
            this.gpbCountyData.Controls.Add(this.btnSearch);
            this.gpbCountyData.Controls.Add(this.btnDelete);
            this.gpbCountyData.Controls.Add(this.txtInflation);
            this.gpbCountyData.Controls.Add(this.btnUpdate);
            this.gpbCountyData.Controls.Add(this.txtHDI);
            this.gpbCountyData.Controls.Add(this.lblCountry);
            this.gpbCountyData.Controls.Add(this.lblGDP);
            this.gpbCountyData.Controls.Add(this.lblInflation);
            this.gpbCountyData.Controls.Add(this.lblPartners);
            this.gpbCountyData.Controls.Add(this.txtTrade);
            this.gpbCountyData.Controls.Add(this.txtCountry);
            this.gpbCountyData.Controls.Add(this.lblTrade);
            this.gpbCountyData.Controls.Add(this.rtbPartners);
            this.gpbCountyData.Controls.Add(this.txtGDP);
            this.gpbCountyData.Controls.Add(this.lblHDI);
            this.gpbCountyData.Location = new System.Drawing.Point(13, 18);
            this.gpbCountyData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbCountyData.Name = "gpbCountyData";
            this.gpbCountyData.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbCountyData.Size = new System.Drawing.Size(855, 363);
            this.gpbCountyData.TabIndex = 12;
            this.gpbCountyData.TabStop = false;
            this.gpbCountyData.Text = "Country Data";
            // 
            // btnSearch
            // 
            this.btnSearch.Location = new System.Drawing.Point(473, 25);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(141, 34);
            this.btnSearch.TabIndex = 14;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = true;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(199, 303);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(171, 46);
            this.btnDelete.TabIndex = 13;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(20, 303);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(171, 46);
            this.btnUpdate.TabIndex = 12;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // gpbTradeData
            // 
            this.gpbTradeData.Controls.Add(this.lblHighestGDP);
            this.gpbTradeData.Controls.Add(this.lblBestTrade);
            this.gpbTradeData.Controls.Add(this.rtbAllPartners);
            this.gpbTradeData.Controls.Add(this.txtTradeCountry);
            this.gpbTradeData.Controls.Add(this.btnTradeSearch);
            this.gpbTradeData.Location = new System.Drawing.Point(468, 391);
            this.gpbTradeData.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbTradeData.Name = "gpbTradeData";
            this.gpbTradeData.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbTradeData.Size = new System.Drawing.Size(400, 421);
            this.gpbTradeData.TabIndex = 13;
            this.gpbTradeData.TabStop = false;
            this.gpbTradeData.Text = "Trade Data";
            // 
            // lblHighestGDP
            // 
            this.lblHighestGDP.AutoSize = true;
            this.lblHighestGDP.Location = new System.Drawing.Point(337, 342);
            this.lblHighestGDP.Name = "lblHighestGDP";
            this.lblHighestGDP.Size = new System.Drawing.Size(40, 20);
            this.lblHighestGDP.TabIndex = 17;
            this.lblHighestGDP.Text = "num";
            // 
            // lblBestTrade
            // 
            this.lblBestTrade.AutoSize = true;
            this.lblBestTrade.Location = new System.Drawing.Point(10, 342);
            this.lblBestTrade.Name = "lblBestTrade";
            this.lblBestTrade.Size = new System.Drawing.Size(230, 20);
            this.lblBestTrade.TabIndex = 15;
            this.lblBestTrade.Text = "Biggest Potential Trade Partner";
            // 
            // rtbAllPartners
            // 
            this.rtbAllPartners.Location = new System.Drawing.Point(14, 89);
            this.rtbAllPartners.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rtbAllPartners.Name = "rtbAllPartners";
            this.rtbAllPartners.Size = new System.Drawing.Size(374, 248);
            this.rtbAllPartners.TabIndex = 16;
            this.rtbAllPartners.Text = "";
            // 
            // txtTradeCountry
            // 
            this.txtTradeCountry.Location = new System.Drawing.Point(9, 38);
            this.txtTradeCountry.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtTradeCountry.Name = "txtTradeCountry";
            this.txtTradeCountry.Size = new System.Drawing.Size(259, 26);
            this.txtTradeCountry.TabIndex = 15;
            this.txtTradeCountry.TextChanged += new System.EventHandler(this.txtTradeCountry_TextChanged);
            // 
            // btnTradeSearch
            // 
            this.btnTradeSearch.Location = new System.Drawing.Point(279, 34);
            this.btnTradeSearch.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTradeSearch.Name = "btnTradeSearch";
            this.btnTradeSearch.Size = new System.Drawing.Size(112, 35);
            this.btnTradeSearch.TabIndex = 14;
            this.btnTradeSearch.Text = "Search";
            this.btnTradeSearch.UseVisualStyleBackColor = true;
            this.btnTradeSearch.Click += new System.EventHandler(this.btnTradeSearch_Click);
            // 
            // gpbAllNames
            // 
            this.gpbAllNames.Controls.Add(this.lblHeightNum);
            this.gpbAllNames.Controls.Add(this.lblHeight);
            this.gpbAllNames.Controls.Add(this.lblCount);
            this.gpbAllNames.Controls.Add(this.lblNodes);
            this.gpbAllNames.Controls.Add(this.rtbAllCountries);
            this.gpbAllNames.Location = new System.Drawing.Point(13, 391);
            this.gpbAllNames.Name = "gpbAllNames";
            this.gpbAllNames.Size = new System.Drawing.Size(358, 421);
            this.gpbAllNames.TabIndex = 14;
            this.gpbAllNames.TabStop = false;
            this.gpbAllNames.Text = "All Countries";
            // 
            // lblHeightNum
            // 
            this.lblHeightNum.AutoSize = true;
            this.lblHeightNum.Location = new System.Drawing.Point(289, 375);
            this.lblHeightNum.Name = "lblHeightNum";
            this.lblHeightNum.Size = new System.Drawing.Size(40, 20);
            this.lblHeightNum.TabIndex = 19;
            this.lblHeightNum.Text = "num";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(8, 375);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(101, 20);
            this.lblHeight.TabIndex = 18;
            this.lblHeight.Text = "Hight of Tree";
            // 
            // lblCount
            // 
            this.lblCount.AutoSize = true;
            this.lblCount.Location = new System.Drawing.Point(289, 342);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(40, 20);
            this.lblCount.TabIndex = 17;
            this.lblCount.Text = "num";
            // 
            // lblNodes
            // 
            this.lblNodes.AutoSize = true;
            this.lblNodes.Location = new System.Drawing.Point(8, 342);
            this.lblNodes.Name = "lblNodes";
            this.lblNodes.Size = new System.Drawing.Size(155, 20);
            this.lblNodes.TabIndex = 16;
            this.lblNodes.Text = "Number of Countries";
            // 
            // rtbAllCountries
            // 
            this.rtbAllCountries.Location = new System.Drawing.Point(12, 33);
            this.rtbAllCountries.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rtbAllCountries.Name = "rtbAllCountries";
            this.rtbAllCountries.Size = new System.Drawing.Size(328, 304);
            this.rtbAllCountries.TabIndex = 15;
            this.rtbAllCountries.Text = "";
            // 
            // lblPartial
            // 
            this.lblPartial.AutoSize = true;
            this.lblPartial.Location = new System.Drawing.Point(666, 58);
            this.lblPartial.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPartial.Name = "lblPartial";
            this.lblPartial.Size = new System.Drawing.Size(166, 20);
            this.lblPartial.TabIndex = 16;
            this.lblPartial.Text = "Partial Search Results";
            // 
            // cmbPartial
            // 
            this.cmbPartial.FormattingEnabled = true;
            this.cmbPartial.Location = new System.Drawing.Point(662, 81);
            this.cmbPartial.Name = "cmbPartial";
            this.cmbPartial.Size = new System.Drawing.Size(181, 28);
            this.cmbPartial.TabIndex = 17;
            this.cmbPartial.SelectedIndexChanged += new System.EventHandler(this.cmbPartial_SelectedIndexChanged);
            // 
            // frmITD
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 824);
            this.Controls.Add(this.gpbAllNames);
            this.Controls.Add(this.gpbTradeData);
            this.Controls.Add(this.gpbCountyData);
            this.Name = "frmITD";
            this.Text = "International Trading Data";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gpbCountyData.ResumeLayout(false);
            this.gpbCountyData.PerformLayout();
            this.gpbTradeData.ResumeLayout(false);
            this.gpbTradeData.PerformLayout();
            this.gpbAllNames.ResumeLayout(false);
            this.gpbAllNames.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.TextBox txtGDP;
        private System.Windows.Forms.TextBox txtInflation;
        private System.Windows.Forms.TextBox txtTrade;
        private System.Windows.Forms.RichTextBox rtbPartners;
        private System.Windows.Forms.TextBox txtHDI;
        private System.Windows.Forms.Label lblGDP;
        private System.Windows.Forms.Label lblInflation;
        private System.Windows.Forms.Label lblTrade;
        private System.Windows.Forms.Label lblHDI;
        private System.Windows.Forms.Label lblCountry;
        private System.Windows.Forms.Label lblPartners;
        private System.Windows.Forms.GroupBox gpbCountyData;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.GroupBox gpbTradeData;
        private System.Windows.Forms.RichTextBox rtbAllPartners;
        private System.Windows.Forms.TextBox txtTradeCountry;
        private System.Windows.Forms.Button btnTradeSearch;
        private System.Windows.Forms.GroupBox gpbAllNames;
        private System.Windows.Forms.RichTextBox rtbAllCountries;
        private System.Windows.Forms.Label lblHeightNum;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Label lblNodes;
        private System.Windows.Forms.Label lblHighestGDP;
        private System.Windows.Forms.Label lblBestTrade;
        private System.Windows.Forms.Label lblPartial;
        private System.Windows.Forms.ComboBox cmbPartial;
    }
}

