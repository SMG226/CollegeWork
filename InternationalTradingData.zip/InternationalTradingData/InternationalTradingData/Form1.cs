﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InternationalTradingData
{
    public partial class frmITD : Form 
    {
        Node<Country> countryNode;
        Country cSearch = new Country(null, 0, 0, 0, 0, null);
        string oldName;
        private CountryTree<Country> tree = new CountryTree<Country>();
        public frmITD(CountryTree<Country> Tree)
        {
            InitializeComponent();
            this.tree = Tree;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            loadAllcountries();
            setTextChanged(txtCountry);
            setTextChanged(txtTradeCountry);
        }
        private void loadAllcountries()
        {
            rtbAllCountries.Clear();
            string buffer = "";
            tree.InOrder(ref buffer);
            string[] cList = buffer.Split(',');
            foreach (string cItem in cList)
            {
                rtbAllCountries.AppendText(cItem + "\n");
            }
            lblCount.Text = tree.Count().ToString();
            lblHeightNum.Text = tree.Height().ToString();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            cSearch.Name = txtCountry.Text;
            SearchItem();
        }
        private void SearchItem()
        {
            countryNode = tree.GetItem(cSearch);
            if (countryNode != null)
            {
                rtbPartners.Clear();
                txtCountry.Text = countryNode.Data.Name;
                oldName = countryNode.Data.Name;
                txtGDP.Text = countryNode.Data.GDP.ToString();
                txtInflation.Text = countryNode.Data.Inflation.ToString();
                txtTrade.Text = countryNode.Data.TradeBalance.ToString();
                txtHDI.Text = countryNode.Data.HDI.ToString();
                foreach (string s in countryNode.Data.TradePartners)
                {
                    rtbPartners.AppendText(s + "\n");

                }//End of Foreach
            }
            else
            {
                cmbPartial.Items.Clear();
                txtCountry.Clear();
                txtCountry.Text = "No Country In Tree";
                LinkedList<string> searchNames = new LinkedList<string>();
                searchNames = tree.PartialSearch(cSearch);
                foreach (string s in searchNames)
                {
                    cmbPartial.Items.Add(s);
                }//End of Foreach
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (countryNode != null)
            {
                if (txtCountry.Text != "" && txtGDP.Text != "" && txtHDI.Text != "" && txtInflation.Text != "" && txtTrade.Text != "" && rtbPartners.Text != "")
                {
                    if (tree.Contains(countryNode.Data))
                    {
                        countryNode.Data.Name = txtCountry.Text;
                        countryNode.Data.HDI = Convert.ToInt32(txtHDI.Text);
                        countryNode.Data.GDP = Convert.ToDecimal(txtGDP.Text);
                        countryNode.Data.TradeBalance = Convert.ToDecimal(txtTrade.Text);
                        countryNode.Data.Inflation = Convert.ToDecimal(txtInflation.Text);
                        countryNode.Data.TradePartners = new LinkedList<string>();
                        foreach (string line in rtbPartners.Lines)
                        {
                            countryNode.Data.TradePartners.AddFirst(line);
                        }//End for each
                        cSearch.Name = oldName;
                        if (tree.Contains(cSearch))
                        {
                            tree.UpdateItem(cSearch, countryNode);
                        }//End if
                    }//End if
                }//End if
                loadAllcountries();
            }//End if
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(countryNode != null)//Prevent deleting items that have already been deleted
            {
                tree.RemoveItem(countryNode.Data);
                countryNode = null;
                loadAllcountries();
            }
        }

        private void txtTradeCountry_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnTradeSearch_Click(object sender, EventArgs e)
        {
            cSearch.Name = txtTradeCountry.Text;
            rtbAllPartners.Clear();
            string buffer = "";
            decimal HighestGDP = 0;
            string HighestCountry = "";
            tree.AllPartners(ref buffer, cSearch);
            string[] cList = buffer.Split(',');
            foreach (string cItem in cList)
            {
                rtbAllPartners.AppendText(cItem + "\n");
                cSearch.Name = cItem;
                Node<Country> country = tree.GetItem(cSearch);
                if (country == null)
                {

                }
                else
                {
                    if (HighestGDP < country.Data.GDP)
                    {
                        HighestGDP = tree.GetItem(cSearch).Data.GDP;
                        HighestCountry = tree.GetItem(cSearch).Data.Name;
                    }
                }
            }//End of foreach
            lblHighestGDP.Text = HighestCountry;
        }

        private void txtCountry_TextChanged(object sender, EventArgs e)
        {

        }
        private void setTextChanged(TextBox txt)
        {
            string buffer = "";
            tree.InOrder(ref buffer);
            txt.AutoCompleteMode = AutoCompleteMode.Suggest;
            txt.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection countries = new AutoCompleteStringCollection();
            string[] cList = buffer.Split(',');
            foreach (string cItem in cList)
            {
                countries.Add(cItem);
            }
            txt.AutoCompleteCustomSource = countries;
        }
        private void cmbPartial_SelectedIndexChanged(object sender, EventArgs e)
        {
            cSearch.Name = cmbPartial.SelectedItem.ToString();
            SearchItem();
        }
    }
}
